import java.util.HashMap;
import java.util.Map;
class Product {
    int productId;
    String productName;
    int quantity;
    double price;
    public Product(int productId, String productName, int quantity, double price) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }
}
class InventoryManagementSystem {
    private Map<Integer, Product> inventory;
    public InventoryManagementSystem() {
        this.inventory = new HashMap<>();
    }
    public void addProduct(Product product) {
        inventory.put(product.productId, product);
    }
    public void updateProduct(Product product) {
        if (inventory.containsKey(product.productId)) {
            inventory.put(product.productId, product);
        } else {
            System.out.println("Product not found.");
        }
    }
    public void deleteProduct(int productId) {
        inventory.remove(productId);
    }
    public Product getProduct(int productId) {
        return inventory.get(productId);
    }
}
public class InventoryManagementSystemExample {
    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();
        Product p1 = new Product(1, "Product1", 10, 100.0);
        Product p2 = new Product(2, "Product2", 20, 200.0);
        ims.addProduct(p1);
        ims.addProduct(p2);
        ims.updateProduct(new Product(1, "UpdatedProduct1", 15, 150.0));
        Product p = ims.getProduct(1);
        System.out.println("Product Name: " + p.productName);
        ims.deleteProduct(2);
    }
}
