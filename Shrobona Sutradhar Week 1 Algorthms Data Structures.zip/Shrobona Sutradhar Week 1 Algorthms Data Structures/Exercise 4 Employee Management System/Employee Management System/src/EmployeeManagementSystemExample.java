class Employee {
    int employeeId;
    String name;
    String position;
    double salary;
    public Employee(int employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }
}
class EmployeeManagementSystem {
    private Employee[] employees;
    private int count;
    public EmployeeManagementSystem(int size) {
        this.employees = new Employee[size];
        this.count = 0;
    }
    public void addEmployee(Employee employee) {
        if (count < employees.length) {
            employees[count++] = employee;
        } else {
            System.out.println("Array is full.");
        }
    }
    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].employeeId == employeeId) {
                return employees[i];
            }
        }
        return null;
    }
    public void deleteEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].employeeId == employeeId) {
                employees[i] = employees[count - 1];
                employees[count - 1] = null;
                count--;
                break;
            }
        }
    }
    public void traverseEmployees() {
        for (int i = 0; i < count; i++) {
            System.out.println(employees[i].name);
        }
    }
}
public class EmployeeManagementSystemExample {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(10);
        Employee e1 = new Employee(1, "John", "Manager", 5000.0);
        Employee e2 = new Employee(2, "Jane", "Developer", 4000.0);
        ems.addEmployee(e1);
        ems.addEmployee(e2);
        ems.traverseEmployees();
        ems.deleteEmployee(1);
        ems.traverseEmployees();
    }
}
