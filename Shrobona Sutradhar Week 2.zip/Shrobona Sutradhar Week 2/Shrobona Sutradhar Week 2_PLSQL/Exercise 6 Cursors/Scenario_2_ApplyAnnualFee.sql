DECLARE
    CURSOR ApplyAnnualFee IS
        SELECT account_id, balance
        FROM accounts;

    v_account_id  accounts.account_id%TYPE;
    v_balance     accounts.balance%TYPE;

    c_annual_fee CONSTANT NUMBER := 100; -- Annual fee amount
BEGIN
    OPEN ApplyAnnualFee;
    LOOP
        FETCH ApplyAnnualFee INTO v_account_id, v_balance;
        EXIT WHEN ApplyAnnualFee%NOTFOUND;

        
        v_balance := v_balance - c_annual_fee;

        
        UPDATE accounts
        SET balance = v_balance
        WHERE account_id = v_account_id;

        DBMS_OUTPUT.PUT_LINE('Account ID: ' || v_account_id || ' - New Balance: ' || v_balance);
    END LOOP;
    CLOSE ApplyAnnualFee;

    COMMIT; 
END;
/