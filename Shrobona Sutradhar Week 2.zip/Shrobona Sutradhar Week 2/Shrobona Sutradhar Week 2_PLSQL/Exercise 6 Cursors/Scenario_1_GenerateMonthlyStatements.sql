DECLARE
    CURSOR GenerateMonthlyStatements IS
        SELECT customer_id, transaction_date, transaction_amount
        FROM transactions
        WHERE transaction_date BETWEEN TRUNC(SYSDATE, 'MM') AND LAST_DAY(SYSDATE);

    v_customer_id       transactions.customer_id%TYPE;
    v_transaction_date  transactions.transaction_date%TYPE;
    v_transaction_amount transactions.transaction_amount%TYPE;
BEGIN
    OPEN GenerateMonthlyStatements;
    LOOP
        FETCH GenerateMonthlyStatements INTO v_customer_id, v_transaction_date, v_transaction_amount;
        EXIT WHEN GenerateMonthlyStatements%NOTFOUND;

        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || v_customer_id);
        DBMS_OUTPUT.PUT_LINE('Transaction Date: ' || v_transaction_date);
        DBMS_OUTPUT.PUT_LINE('Transaction Amount: ' || v_transaction_amount);
    END LOOP;
    CLOSE GenerateMonthlyStatements;
END;
/