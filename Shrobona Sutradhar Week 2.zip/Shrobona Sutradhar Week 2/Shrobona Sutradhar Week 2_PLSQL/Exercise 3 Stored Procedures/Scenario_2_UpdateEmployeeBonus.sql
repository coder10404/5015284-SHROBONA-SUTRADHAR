CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus (
    p_Department IN Employees.Department%TYPE,
    p_BonusPercentage IN NUMBER
) IS
    CURSOR employee_cursor IS
        SELECT EmployeeID, Salary
        FROM Employees
        WHERE Department = p_Department;
    
    v_EmployeeID Employees.EmployeeID%TYPE;
    v_Salary Employees.Salary%TYPE;
BEGIN
    FOR employee_record IN employee_cursor LOOP
        v_EmployeeID := employee_record.EmployeeID;
        v_Salary := employee_record.Salary;
        
        
        v_Salary := v_Salary + (v_Salary * p_BonusPercentage / 100);
        
        
        UPDATE Employees
        SET Salary = v_Salary, LastModified = SYSDATE
        WHERE EmployeeID = v_EmployeeID;
    END LOOP;
    
    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        INSERT INTO ErrorLog (ErrorMessage, ErrorDate)
        VALUES (SQLERRM, SYSDATE);
        RAISE;
END UpdateEmployeeBonus;
/