CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest IS
    CURSOR savings_cursor IS
        SELECT AccountID, Balance
        FROM Accounts
        WHERE AccountType = 'Savings';
    
    v_AccountID Accounts.AccountID%TYPE;
    v_Balance Accounts.Balance%TYPE;
BEGIN
    FOR account_record IN savings_cursor LOOP
        v_AccountID := account_record.AccountID;
        v_Balance := account_record.Balance;
        
        
        v_Balance := v_Balance + (v_Balance * 0.01);
        
        
        UPDATE Accounts
        SET Balance = v_Balance, LastModified = SYSDATE
        WHERE AccountID = v_AccountID;
    END LOOP;
    
    COMMIT;
END ProcessMonthlyInterest;
/