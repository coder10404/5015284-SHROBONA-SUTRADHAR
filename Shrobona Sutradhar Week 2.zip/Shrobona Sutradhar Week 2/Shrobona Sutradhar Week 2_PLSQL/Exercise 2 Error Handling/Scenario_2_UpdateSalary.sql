CREATE OR REPLACE PROCEDURE UpdateSalary (
    p_EmployeeID IN Employees.EmployeeID%TYPE,
    p_Percentage IN NUMBER
) IS
    v_Salary Employees.Salary%TYPE;
BEGIN
    
    SELECT Salary INTO v_Salary FROM Employees WHERE EmployeeID = p_EmployeeID FOR UPDATE;

    
    UPDATE Employees
    SET Salary = Salary + (Salary * p_Percentage / 100)
    WHERE EmployeeID = p_EmployeeID;

    COMMIT;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        INSERT INTO ErrorLog (ErrorMessage, ErrorDate)
        VALUES ('Employee ID ' || p_EmployeeID || ' does not exist.', SYSDATE);
        ROLLBACK;
    WHEN OTHERS THEN
        INSERT INTO ErrorLog (ErrorMessage, ErrorDate)
        VALUES (SQLERRM, SYSDATE);
        ROLLBACK;
END UpdateSalary;
/