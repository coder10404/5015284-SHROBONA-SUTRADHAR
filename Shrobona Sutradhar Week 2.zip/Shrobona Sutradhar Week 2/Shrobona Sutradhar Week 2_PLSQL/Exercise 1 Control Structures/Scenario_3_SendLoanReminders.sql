DECLARE
    CURSOR loan_cursor IS
        SELECT l.LoanID, l.CustomerID, l.EndDate, c.Name
        FROM Loans l
        JOIN Customers c ON l.CustomerID = c.CustomerID
        WHERE l.EndDate BETWEEN SYSDATE AND SYSDATE + 30;
    
    v_LoanID Loans.LoanID%TYPE;
    v_CustomerID Loans.CustomerID%TYPE;
    v_EndDate Loans.EndDate%TYPE;
    v_CustomerName Customers.Name%TYPE;
BEGIN
    FOR loan_record IN loan_cursor LOOP
        v_LoanID := loan_record.LoanID;
        v_CustomerID := loan_record.CustomerID;
        v_EndDate := loan_record.EndDate;
        v_CustomerName := loan_record.Name;
        
        
        DBMS_OUTPUT.PUT_LINE('Reminder: Customer ' || v_CustomerName || 
                             ' (Customer ID: ' || v_CustomerID || 
                             ') has a loan due on ' || TO_CHAR(v_EndDate, 'YYYY-MM-DD'));
    END LOOP;
END;
/