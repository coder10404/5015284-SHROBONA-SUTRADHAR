DECLARE
    CURSOR customer_cursor IS
        SELECT c.CustomerID, l.LoanID, l.InterestRate, c.DOB
        FROM Customers c
        JOIN Loans l ON c.CustomerID = l.CustomerID;
    
    v_CustomerID Customers.CustomerID%TYPE;
    v_LoanID Loans.LoanID%TYPE;
    v_InterestRate Loans.InterestRate%TYPE;
    v_DOB Customers.DOB%TYPE;
    v_Age NUMBER;
BEGIN
    FOR customer_record IN customer_cursor LOOP
        v_CustomerID := customer_record.CustomerID;
        v_LoanID := customer_record.LoanID;
        v_InterestRate := customer_record.InterestRate;
        v_DOB := customer_record.DOB;
        
        
        v_Age := TRUNC(MONTHS_BETWEEN(SYSDATE, v_DOB) / 12);
        
        IF v_Age > 60 THEN
            
            v_InterestRate := v_InterestRate * 0.99;
           
            UPDATE Loans
            SET InterestRate = v_InterestRate
            WHERE LoanID = v_LoanID;
        END IF;
    END LOOP;
    COMMIT;
END;
/