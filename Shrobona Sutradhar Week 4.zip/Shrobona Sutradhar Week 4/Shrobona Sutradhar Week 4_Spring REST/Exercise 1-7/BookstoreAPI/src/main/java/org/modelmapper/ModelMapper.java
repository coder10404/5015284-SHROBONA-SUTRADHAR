package org.modelmapper;

import com.book.dto.BookDTO;
import com.book.model.Book;

public class ModelMapper {

	public BookDTO map(Object book, Class<BookDTO> class1) {
		// TODO Auto-generated method stub
		return null;
	}

	public Book map(BookDTO bookDTO, Class<Book> class1) {
		// TODO Auto-generated method stub
		return null;
	}

}
